const str = 'sjdhfuijoa_jksdfbh2134.docx';

console.log(str.split('.'));

const arr = str.split('.');

console.log(arr[arr.length - 1]);