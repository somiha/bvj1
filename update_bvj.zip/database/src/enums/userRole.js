const Roles = {
  AUTHOR: 'author',
  REVIEWER: 'reviewer',
  ADMIN: 'admin'
}

module.exports = Roles;